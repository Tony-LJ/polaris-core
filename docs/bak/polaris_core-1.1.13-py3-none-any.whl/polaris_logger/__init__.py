# -*- coding: utf-8 -*-

from .logger import logger

__all__ = [
    'logger'
]

__version__ = '0.0.1'
__author__ = 'Tony.LJ'