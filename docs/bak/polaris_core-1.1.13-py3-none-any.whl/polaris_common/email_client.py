# -*- coding: utf-8 -*-
"""
descr : 邮件发送
auther : lj.michale
create_date : 2025/10/27 15:54
file_name : email_client.py
"""
import yagmail


class EmailClient:

    def __init__(self):
        print(">>>>>>>>>>")

    def send_text_email(self):
        print(">>>>>>>>>>")


    def send_markdown_email(self):
        print(">>>>>>>>>>")

    def send_html_email(self):
        print(">>>>>>>>>>")