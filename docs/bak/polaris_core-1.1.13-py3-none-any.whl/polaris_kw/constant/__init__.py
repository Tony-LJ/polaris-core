# -*- coding: utf-8 -*-

from .kw_constant import PROD_QUALITY_WEBHOOK_URL


__all__ = [
    'PROD_QUALITY_WEBHOOK_URL'
]
