# -*- coding: utf-8 -*-

# ###################### 生产Prod
# 数仓质检报告消息推送企微机器人
PROD_QUALITY_WEBHOOK_URL = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=f318a3b2-383b-451c-bef3-e637c8df4b07"
# 数仓调度消息推送企微机器人
PROD_WAREHOUSE_WEBHOOK_URL = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key="
# UTC环境消息推送企微机器人
PROD_WAREHOUSE_WEBHOOK_URL = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key="
# KW数据智能助手机器人
PROD_INTELLIGENT_ASSISTANT_ROBOT_URL = "https://work.weixin.qq.com/wework_admin/common/openBotProfile/24411e21f0114006b02886e5cecbaf936e"

# ###################### 其他
