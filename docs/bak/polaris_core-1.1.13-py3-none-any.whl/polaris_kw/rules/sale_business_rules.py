# -*- coding: utf-8 -*-

"""
descr: 销售数据域计算规则
auther: lj.michale
create_date: 2025/9/27 15:54
file_name: sale_business_rules.py
"""

