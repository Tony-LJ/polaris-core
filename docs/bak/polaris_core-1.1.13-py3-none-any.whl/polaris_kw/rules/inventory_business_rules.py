# -*- coding: utf-8 -*-

"""
descr: 库存数据域计算规则
auther: lj.michale
create_date: 2025/9/27 15:54
file_name: inventory_business_rules.py
"""

