# -*- coding: utf-8 -*-

"""
descr: 签收数据域计算规则
auther: lj.michale
create_date: 2025/9/27 15:54
file_name: sign_business_rules.py
"""

