# -*- coding: utf-8 -*-

"""
descr: 人资数据域计算规则
auther: lj.michale
create_date: 2025/9/27 15:54
file_name: hr_business_rules.py
"""

