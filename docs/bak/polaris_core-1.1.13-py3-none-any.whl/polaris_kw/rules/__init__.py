# -*- coding: utf-8 -*-

from .manufacture_business_rules import calc_product_type

__all__ = [
    'calc_product_type'
]
