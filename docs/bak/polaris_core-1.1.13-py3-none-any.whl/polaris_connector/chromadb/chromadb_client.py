# -*- coding: utf-8 -*-

"""
descr: Chromadb客户端
auther: lj.michale
create_date: 2025/10/18 09:54
file_name: ollama_client.py
"""


class ChromadbClient:
    def __init__(self):
        print("ChromaDB：一个向量数据库，用于存储和管理我们的数据嵌入")
