# -*- coding: utf-8 -*-

from .oracle_client import OracleClient

__all__ = [
    'OracleClient',
]
