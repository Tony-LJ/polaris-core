# -*- coding: utf-8 -*-

import pandas as pd
import oracledb
from sqlalchemy import create_engine  # 使用sqlalchemy与oracledb集成
from sqlalchemy.engine import URL  # 从sqlalchemy导入URL类用于构建数据库连接URL

