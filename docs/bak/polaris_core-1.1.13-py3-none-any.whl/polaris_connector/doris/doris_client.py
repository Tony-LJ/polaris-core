# -*- coding: utf-8 -*-

"""
descr: Doris客户端封装
auther: lj.michale
create_date: 2025/9/27 15:54
file_name: doris_client.py
"""

class DorisClient:
    print(">>>>>>>>>>>>>>>>>>>>>")