# -*- coding: utf-8 -*-

from .massage_push_bot import WechatBot
from .massage_push_bot import FeiShuBot
from .massage_push_bot import DingDingBot


__all__ = [
    'WechatBot',
    'FeiShuBot',
    'DingDingBot',
]
