# -*- coding: utf-8 -*-
"""
descr: pulsar consumer客户端
auther: lj.michale
create_date: 2025/10/27 15:54
file_name: pulsar_consumer.py
"""


class PolarisPulsarConsumer:
    print(" >>>>>>>>>>>>>>> ")

