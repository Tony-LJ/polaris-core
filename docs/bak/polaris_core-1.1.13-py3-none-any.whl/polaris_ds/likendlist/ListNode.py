# -*- coding: utf-8 -*-

class ListNode:
    def __init__(self, value=0, next=None):
        self.value = value
        self.next = next
